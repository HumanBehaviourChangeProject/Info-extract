OA-HBCP Corpus (version 1.0)
-------------------------------------------------

The dataset contains 97 JSON-formatted analyses of PDF papers performed by a PDF parsing tool.
Each file corresponds to one Open-Access paper in the field of behavior change.

This file is only the README, the dataset itself comprises 97 .json files which should
be included in the same archive.


Structure of JSON files
-------------------------------------

Each file's top level JSON object first contains several metadata fields, like title and introduction.
It also contains a key called "content", whose value contains the entire content of the PDF as analyzed
by the parser.

Example for the top level object in the file, without its content:

{
  "title": "Effectiveness of a smoking cessation program for peripheral artery disease patients: a randomized controlled trial",
  "shortTitle": "Hennrikus (2010)",
  "filename": "Hennrikus 2010.pdf",
  "introduction": "",
  "content": [ ... ]
}

The content is a JSON array of TEXT and TABLE elements, described thereafter.

The TEXT element contains 3 simple key-value pairs, its type ("TEXT"), the text (contained in the PDF), and the page number.
Example of a TEXT element:

{
  "type": "TEXT",
  "text": "Effectiveness of a Smoking Cessation Program for Peripheral Artery Disease Patients A Randomized Controlled Trial\n\n\n\nSites and participants. Participants were recruited from ...",
  "page": 1
}

The TABLE element is more complex, and describes a table as the list of its cells: a value with its row and column headers. Each header list has
potentially several strings, potentially indicating multiple headers. This is intended.
Example of a TABLE element with 2 cells:

{
  "type": "TABLE",
  "cells": [
    {
      "value": "87.0",
      "rowHeaders": [
        "Used any medication",
        "Used nicotine replacement medication"
      ],
      "columnHeaders": [
        "Percentage of Participants Who Reported Use of Pharmacologic Aids",
        "Intervention",
        "(n = 46)"
      ]
    },
    {
      "value": "67.4",
      "rowHeaders": [
        "Used any medication",
        "Used nicotine replacement medication"
      ],
      "columnHeaders": [
        "Percentage of Participants Who Reported Use of Pharmacologic Aids",
        "Control",
        "(n = 49)"
      ]
    }
  ]
}

Notice the shared first column header, indicating that this header was actually spanning multiple columns
and has sub-headers "Intervention" and "Control".


Extraction process
------------------

Each PDF paper was analyzed using a modified version of GROBID, available at https://github.com/IBM/science-result-extractor.
In particular, it modifies GROBID's handling of tables to work better on scientific papers.
A human and machine-friendly JSON file was then generated from this analysis, with very little human control.
As such, it is possible to encounter strange text or strange table interpretations and this is likely due to an error from the PDF parser.


Licensing and copyright
-----------------------

The dataset is released under a Creative Commons license, CC BY-SA 3.0,
the details of which are available here: https://creativecommons.org/licenses/by-sa/3.0/


Citation
--------
If you use the data, please cite the following publication:

	[Anonymized for submission]
