#!/bin/bash

pip install flair

python3 Flair-NER-HBCP-for-DLaaS-train.py

echo "END"
