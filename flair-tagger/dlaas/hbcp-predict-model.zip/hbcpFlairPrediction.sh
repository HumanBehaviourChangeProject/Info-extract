#!/bin/bash

pip install flair

python3 flairPrediction.py

echo "END"
